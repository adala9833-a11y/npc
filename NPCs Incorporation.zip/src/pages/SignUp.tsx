import { motion } from "motion/react";
import { useNavigate, Link } from "react-router-dom";
import { 
  ArrowLeft, User, Mail, Phone, Lock, Eye, EyeOff, 
  ArrowRight, ShieldCheck, CheckCircle2, GraduationCap, Heart, Sparkles 
} from "lucide-react";
import { NpcsLogo } from "../components/NpcsLogo";
import { useState } from "react";
import { useUser } from "../contexts/UserContext";

export function SignUp() {
  const navigate = useNavigate();
  const { setUser } = useUser();
  const [role, setRole] = useState<'Student' | 'Teacher'>('Student');
  const [showPassword, setShowPassword] = useState(false);
  const [formData, setFormData] = useState({
    fullName: "",
    email: "",
    mobileNumber: "",
    password: "",
    confirmPassword: "",
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real app, validation and role-specific logic would go here
    const [firstName, ...lastNameParts] = formData.fullName.split(' ');
    setUser({
      firstName: firstName || "Learner",
      lastName: lastNameParts.join(' ') || "",
      email: formData.email,
      mobileNumber: formData.mobileNumber,
      role: role,
    });
    navigate("/welcome");
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  return (
    <div className="min-h-screen bg-[#09090B] text-white font-sans p-6 md:p-12 relative overflow-hidden flex flex-col items-center">
      {/* Decorative elements */}
      <div className="absolute top-10 right-20 w-32 h-32 bg-indigo-500/10 rounded-full blur-3xl" />
      <div className="absolute bottom-20 left-20 w-48 h-48 bg-purple-500/10 rounded-full blur-3xl" />
      
      <div className="w-full max-w-5xl flex flex-col items-center">
        <div className="w-full flex justify-between items-center mb-12">
          <button 
            onClick={() => navigate("/")}
            className="flex items-center gap-2 text-gray-500 hover:text-indigo-400 font-bold transition-colors group"
          >
            <ArrowLeft className="w-5 h-5 group-hover:-translate-x-1 transition-transform" />
            <span className="text-sm">Back to Home</span>
          </button>
          
          <div className="flex items-center gap-2 text-sm">
             <span className="text-gray-500 font-medium">Already have an account?</span>
             <button onClick={() => navigate("/home")} className="text-indigo-400 font-black border-2 border-indigo-500/20 px-4 py-1.5 rounded-full hover:bg-white/5 transition-all">Sign In</button>
          </div>
        </div>

        <div className="flex flex-col items-center mb-10">
          <NpcsLogo className="w-20 h-20 text-indigo-400 mb-6" />
          <h1 className="text-4xl md:text-5xl font-black text-center tracking-tight leading-none mb-4">
            Create Your <span className="text-indigo-400">Account</span>
          </h1>
          <p className="text-gray-500 font-medium text-center">
            Join <span className="text-indigo-200 font-black">STUDYBROODY</span> and start your smart learning journey today!
          </p>
        </div>

        <div className="w-full max-w-xl bg-[#18181B] rounded-[40px] shadow-2xl p-8 md:p-12 border border-white/5 relative z-10">
          <div className="grid grid-cols-2 gap-4 mb-8">
            <button 
              onClick={() => setRole('Student')}
              className={`flex items-center justify-center gap-3 py-4 rounded-2xl font-black transition-all border-2 ${role === 'Student' ? 'bg-indigo-600 border-indigo-600 text-white shadow-lg shadow-indigo-600/20' : 'bg-white/5 border-transparent text-gray-500 hover:bg-white/10'}`}
            >
              <img src="https://api.dicebear.com/7.x/adventurer/svg?seed=Felix" alt="Student" className="w-6 h-6 rounded-full bg-white/20" />
              I'm a Student
            </button>
            <button 
              onClick={() => setRole('Teacher')}
              className={`flex items-center justify-center gap-3 py-4 rounded-2xl font-black transition-all border-2 ${role === 'Teacher' ? 'bg-indigo-600 border-indigo-600 text-white shadow-lg shadow-indigo-600/20' : 'bg-white/5 border-transparent text-gray-500 hover:bg-white/10'}`}
            >
              <img src="https://api.dicebear.com/7.x/adventurer/svg?seed=Aneka" alt="Teacher" className="w-6 h-6 rounded-full bg-white/20" />
              I'm a Teacher
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-1">
              <label className="text-[13px] font-bold text-gray-500 ml-4">Full Name</label>
              <div className="relative">
                <User className="absolute left-6 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-600" />
                <input
                  required
                  type="text"
                  name="fullName"
                  placeholder="Enter your full name"
                  value={formData.fullName}
                  onChange={handleChange}
                  className="w-full pl-16 pr-6 py-4 bg-white/5 rounded-2xl border-2 border-transparent focus:border-indigo-500/30 focus:outline-none transition-all font-bold placeholder:font-medium placeholder:text-gray-700 text-white"
                />
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-[13px] font-bold text-gray-500 ml-4">Email Address</label>
              <div className="relative">
                <Mail className="absolute left-6 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-600" />
                <input
                  required
                  type="email"
                  name="email"
                  placeholder="Enter your email"
                  value={formData.email}
                  onChange={handleChange}
                  className="w-full pl-16 pr-6 py-4 bg-white/5 rounded-2xl border-2 border-transparent focus:border-indigo-500/30 focus:outline-none transition-all font-bold placeholder:font-medium placeholder:text-gray-700 text-white"
                />
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-[13px] font-bold text-gray-500 ml-4">Mobile Number</label>
              <div className="relative">
                <Phone className="absolute left-6 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-600" />
                <div className="absolute left-14 top-1/2 -translate-y-1/2 h-6 w-[1px] bg-white/10" />
                <input
                  required
                  type="tel"
                  name="mobileNumber"
                  placeholder="Enter your mobile number"
                  value={formData.mobileNumber}
                  onChange={handleChange}
                  className="w-full pl-24 pr-6 py-4 bg-white/5 rounded-2xl border-2 border-transparent focus:border-indigo-500/30 focus:outline-none transition-all font-bold placeholder:font-medium placeholder:text-gray-700 text-white"
                />
                <div className="absolute left-16 top-1/2 -translate-y-1/2 flex items-center gap-1">
                   <img src="https://flagcdn.com/in.svg" alt="IN" className="w-4" />
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-1">
                <label className="text-[13px] font-bold text-gray-500 ml-4">Password</label>
                <div className="relative">
                  <Lock className="absolute left-6 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-600" />
                  <input
                    required
                    type={showPassword ? "text" : "password"}
                    name="password"
                    placeholder="Create a password"
                    value={formData.password}
                    onChange={handleChange}
                    className="w-full pl-16 pr-12 py-4 bg-white/5 rounded-2xl border-2 border-transparent focus:border-indigo-500/30 focus:outline-none transition-all font-bold placeholder:font-medium placeholder:text-gray-700 text-white"
                  />
                  <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-6 top-1/2 -translate-y-1/2 text-gray-600 hover:text-indigo-400">
                    {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                </div>
              </div>
              <div className="space-y-1">
                <label className="text-[13px] font-bold text-gray-500 ml-4">Confirm Password</label>
                <div className="relative">
                  <Lock className="absolute left-6 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-600" />
                  <input
                    required
                    type={showPassword ? "text" : "password"}
                    name="confirmPassword"
                    placeholder="Confirm your password"
                    value={formData.confirmPassword}
                    onChange={handleChange}
                    className="w-full pl-16 pr-12 py-4 bg-white/5 rounded-2xl border-2 border-transparent focus:border-indigo-500/30 focus:outline-none transition-all font-bold placeholder:font-medium placeholder:text-gray-700 text-white"
                  />
                </div>
              </div>
            </div>

            <div className="flex items-center gap-3 px-2">
              <input type="checkbox" required className="w-5 h-5 rounded-lg border-white/10 bg-white/5 text-indigo-600 focus:ring-0 cursor-pointer" />
              <label className="text-sm font-bold text-gray-500">
                I agree to the <a href="#" className="text-indigo-400 font-extrabold hover:underline">Terms of Service</a> and <a href="#" className="text-indigo-400 font-extrabold hover:underline">Privacy Policy</a>
              </label>
            </div>

            <button
              type="submit"
              className="w-full py-5 bg-indigo-600 text-white font-black rounded-[20px] text-lg flex items-center justify-center gap-3 shadow-xl shadow-indigo-600/20 hover:scale-[1.01] transition-all group"
            >
              Create Account
              <ArrowRight className="w-6 h-6 group-hover:translate-x-1 transition-transform" />
            </button>
          </form>

          <div className="my-10 flex items-center gap-4 text-white/5">
            <div className="flex-1 h-[1px] bg-white/5" />
            <span className="text-[11px] font-bold uppercase tracking-widest whitespace-nowrap text-gray-600">or sign up with</span>
            <div className="flex-1 h-[1px] bg-white/5" />
          </div>

          <div className="grid grid-cols-3 gap-4">
            {[
              { name: 'Google', icon: 'https://www.google.com/favicon.ico' },
              { name: 'Microsoft', icon: 'https://www.microsoft.com/favicon.ico' },
              { name: 'Apple', icon: 'https://www.apple.com/favicon.ico' }
            ].map((social) => (
              <button key={social.name} className="flex items-center justify-center gap-2 py-4 bg-white/5 rounded-2xl border-2 border-transparent hover:bg-white/10 hover:border-white/5 transition-all font-bold text-sm text-gray-300">
                <img src={social.icon} alt={social.name} className="w-5 h-5 rounded-sm" />
                <span className="hidden md:inline">{social.name}</span>
              </button>
            ))}
          </div>
        </div>

        <div className="mt-12 flex flex-col md:flex-row items-center gap-8 text-gray-500">
           <div className="flex items-center gap-3">
              <User className="w-5 h-5 text-indigo-500/60" />
              <div className="flex flex-col">
                 <span className="text-[13px] font-black text-gray-400">Personalized Learning</span>
                 <span className="text-[10px] font-bold">Tailored for every learner</span>
              </div>
           </div>
           <div className="flex items-center gap-3">
              <Sparkles className="w-5 h-5 text-amber-500/60" />
              <div className="flex flex-col">
                 <span className="text-[13px] font-black text-gray-400">Smart Tools</span>
                 <span className="text-[10px] font-bold">AI-powered assistance</span>
              </div>
           </div>
           <div className="flex items-center gap-3">
              <GraduationCap className="w-5 h-5 text-indigo-500/60" />
              <div className="flex flex-col">
                 <span className="text-[13px] font-black text-gray-400">For Everyone</span>
                 <span className="text-[10px] font-bold">Students & Teachers</span>
              </div>
           </div>
           <div className="flex items-center gap-3">
              <Heart className="w-5 h-5 text-rose-500/60" />
              <div className="flex flex-col">
                 <span className="text-[13px] font-black text-gray-400">Learn Together</span>
                 <span className="text-[10px] font-bold">Build a better future</span>
              </div>
           </div>
        </div>
        
        <div className="mt-12 pb-12">
            <div className="bg-indigo-500/5 px-6 py-4 rounded-[28px] border border-indigo-500/10 flex items-center gap-4 relative shadow-2xl">
                <ShieldCheck className="w-10 h-10 text-indigo-400" />
                <div>
                   <h4 className="text-sm font-black text-indigo-200 leading-none mb-1">Safe. Secure. Trusted.</h4>
                   <p className="text-[10px] font-bold text-indigo-500/60">Your information is protected with industry-leading security.</p>
                </div>
                <div className="absolute -top-3 -right-3 w-8 h-8 rounded-full bg-[#18181B] shadow-md flex items-center justify-center border border-white/5">
                   <CheckCircle2 className="w-5 h-5 text-emerald-500" />
                </div>
            </div>
        </div>
      </div>

      <div className="hidden lg:block absolute bottom-10 left-10 w-64 h-64 opacity-10 filter grayscale group transition-all hover:opacity-100 hover:grayscale-0">
         <img src="https://api.dicebear.com/7.x/adventurer/svg?seed=Felix" alt="Felix" className="w-full h-full" />
      </div>
    </div>
  );
}
