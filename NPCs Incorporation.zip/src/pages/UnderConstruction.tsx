import { Link } from "react-router-dom";
import { motion } from "motion/react";

export function UnderConstruction() {
  return (
    <div className="h-full flex flex-col items-center justify-center max-w-2xl mx-auto text-center px-6">
      <motion.div
        initial={{ y: 20, opacity: 0, scale: 0.95 }}
        animate={{ y: 0, opacity: 1, scale: 1 }}
        transition={{ duration: 0.5 }}
        className="w-full max-w-[500px] mb-6 rounded-2xl overflow-hidden bg-[#18181B] border border-[#ffffff14] shadow-2xl relative"
      >
        {/* Placeholder for the user's uploaded image */}
        <img 
          src="/under-construction.jpg" 
          alt="Under Construction Illustration" 
          className="w-full h-auto object-cover"
          referrerPolicy="no-referrer"
          onError={(e) => {
            // Fallback in case the image hasn't been uploaded yet
            (e.target as HTMLImageElement).src = `https://images.unsplash.com/photo-1541888047434-d02ceecd9b8b?q=80&w=800&auto=format&fit=crop`;
          }}
        />
      </motion.div>
      
      <motion.h1 
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.5, delay: 0.1 }}
        className="text-[32px] font-bold text-[#E4E4E7] tracking-[-0.03em] mb-4"
      >
        Under Construction
      </motion.h1>
      
      <motion.p 
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.5, delay: 0.2 }}
        className="text-[#71717A] text-[16px] mb-8"
      >
        We're working hard to bring this product to life. Check back soon for updates from NPCs Inc.
      </motion.p>
      
      <motion.div
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.5, delay: 0.3 }}
      >
        <Link 
          to="/home"
          className="inline-flex items-center justify-center px-6 py-3 border border-[#ffffff14] text-[14px] font-semibold rounded-[10px] text-[#71717A] bg-[#18181B] hover:text-[#E4E4E7] hover:bg-[#ffffff0d] transition-colors"
        >
          Back to Home
        </Link>
      </motion.div>
    </div>
  );
}
