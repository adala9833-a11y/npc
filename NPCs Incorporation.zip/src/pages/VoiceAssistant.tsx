import { motion } from "motion/react";
import { Mic, X, Volume2, Sparkles, Brain } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useState, useEffect } from "react";

export function VoiceAssistant() {
  const navigate = useNavigate();
  const [isListening, setIsListening] = useState(true);
  const [transcript, setTranscript] = useState("How can I help you today?");

  useEffect(() => {
    const timer = setTimeout(() => {
      if (isListening) {
        setTranscript("I'm listening... Tell me what's on your mind.");
      }
    }, 2000);
    return () => clearTimeout(timer);
  }, [isListening]);

  return (
    <div className="fixed inset-0 bg-[#09090B] z-50 flex flex-col items-center justify-center p-6 text-white overflow-hidden">
      <button 
        onClick={() => navigate(-1)}
        className="absolute top-8 right-8 w-12 h-12 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center hover:bg-white/10 transition-all"
      >
        <X className="w-6 h-6 text-gray-400" />
      </button>

      <div className="flex flex-col items-center gap-12 relative z-10 w-full max-w-2xl text-center">
        <div className="flex flex-col items-center gap-4">
           <div className="px-4 py-2 bg-indigo-500/10 border border-indigo-500/20 rounded-full flex items-center gap-2 mb-4">
              <Brain className="w-4 h-4 text-indigo-400" />
              <span className="text-[10px] font-black uppercase tracking-widest text-indigo-300">BROODY Voice AI</span>
           </div>
           <h2 className="text-3xl md:text-5xl font-black tracking-tight leading-tight px-4 transition-all duration-500">
             {transcript}
           </h2>
        </div>

        {/* Visualizer */}
        <div className="flex items-center gap-1.5 h-32">
          {[...Array(12)].map((_, i) => (
            <motion.div
              key={i}
              animate={{ 
                height: isListening ? [20, Math.random() * 80 + 20, 20] : 12,
                opacity: isListening ? [0.4, 1, 0.4] : 0.2
              }}
              transition={{ 
                repeat: Infinity, 
                duration: 0.5 + Math.random() * 0.5, 
                delay: i * 0.05 
              }}
              className="w-2 bg-indigo-500 rounded-full"
            />
          ))}
        </div>

        <div className="flex flex-col items-center gap-6">
           <button
             onClick={() => setIsListening(!isListening)}
             className={`w-24 h-24 rounded-full flex items-center justify-center transition-all duration-300 ${isListening ? 'bg-indigo-600 scale-110 shadow-[0_0_40px_rgba(79,70,229,0.4)]' : 'bg-[#18181B] border border-white/10'}`}
           >
             {isListening ? <Mic className="w-10 h-10" /> : <Volume2 className="w-10 h-10 text-gray-500" />}
           </button>
           
           <p className="text-gray-500 font-bold uppercase tracking-widest text-[11px]">
             {isListening ? "Listening..." : "Tap to speak"}
           </p>
        </div>
      </div>

      <div className="absolute bottom-12 flex items-center gap-3 px-6 py-3 bg-white/5 border border-white/5 rounded-2xl">
         <Sparkles className="w-4 h-4 text-amber-500" />
         <span className="text-sm font-bold text-gray-400">Powered by NPCs Intelligence Core</span>
      </div>
    </div>
  );
}
