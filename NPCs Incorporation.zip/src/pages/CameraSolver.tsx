import { motion } from "motion/react";
import { Camera, X, Zap, Scan, Sparkles, Brain, Image as ImageIcon } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useState, useRef, useEffect } from "react";

export function CameraSolver() {
  const navigate = useNavigate();
  const videoRef = useRef<HTMLVideoElement>(null);
  const [isScanning, setIsScanning] = useState(false);
  const [progress, setProgress] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const startCamera = async () => {
    setError(null);
    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        throw new Error("Camera API not supported in this browser.");
      }
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { 
          facingMode: 'environment'
        } 
      });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
    } catch (err) {
      console.error("Camera access denied or not available:", err);
      const msg = err instanceof Error ? err.message : String(err);
      if (msg.includes("Permission denied") || msg.includes("denied") || msg.includes("NotAllowedError")) {
        setError("Camera permission denied. You can try opening in a new tab or simply upload a photo of your question below.");
      } else {
        setError("Could not access camera. Please ensure no other app is using it or use the upload option below.");
      }
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      handleScan();
    }
  };

  useEffect(() => {
    startCamera();

    return () => {
      if (videoRef.current?.srcObject) {
        const stream = videoRef.current.srcObject as MediaStream;
        stream.getTracks().forEach(track => track.stop());
      }
    };
  }, []);

  const handleScan = () => {
    setIsScanning(true);
    let p = 0;
    const interval = setInterval(() => {
      p += 5;
      setProgress(p);
      if (p >= 100) {
        clearInterval(interval);
        setTimeout(() => {
          navigate('/chat');
        }, 500);
      }
    }, 100);
  };

  return (
    <div className="fixed inset-0 bg-black z-50 flex flex-col">
      {/* Viewport */}
      <div className="relative flex-1 overflow-hidden">
        <video 
          ref={videoRef} 
          autoPlay 
          playsInline 
          className="w-full h-full object-cover"
        />
        
        {/* UI Overlay */}
        <div className="absolute inset-0 flex flex-col">
          {/* Header */}
          <div className="p-6 flex items-center justify-between bg-gradient-to-b from-black/60 to-transparent">
             <button onClick={() => navigate(-1)} className="w-10 h-10 rounded-full bg-black/40 flex items-center justify-center text-white backdrop-blur-md">
                <X className="w-6 h-6" />
             </button>
             <div className="flex items-center gap-2 px-4 py-2 bg-indigo-500/20 border border-indigo-500/30 rounded-full backdrop-blur-md">
                <Brain className="w-4 h-4 text-indigo-400" />
                <span className="text-[10px] font-black uppercase tracking-widest text-indigo-100">BROODY Vision AI</span>
             </div>
             <button className="w-10 h-10 rounded-full bg-black/40 flex items-center justify-center text-white backdrop-blur-md">
                <Zap className="w-5 h-5 text-amber-500" />
             </button>
          </div>

          {/* Scanning Frame */}
          <div className="flex-1 flex flex-col items-center justify-center p-8">
             {error ? (
               <div className="bg-white/10 backdrop-blur-xl border border-white/10 p-8 rounded-[32px] max-w-sm w-full text-center flex flex-col items-center gap-6">
                 <div className="w-16 h-16 rounded-2xl bg-rose-500/20 flex items-center justify-center text-rose-500">
                    <Camera className="w-8 h-8" />
                 </div>
                 <div>
                    <h3 className="text-xl font-bold text-white mb-2">Camera Needed</h3>
                    <p className="text-sm text-gray-400 font-medium">
                      {error}
                    </p>
                 </div>
                 <div className="flex flex-col w-full gap-3">
                    <button 
                      onClick={startCamera}
                      className="w-full py-3 bg-indigo-600 text-white font-black rounded-2xl"
                    >
                      Try Again
                    </button>
                    <button 
                      onClick={() => fileInputRef.current?.click()}
                      className="w-full py-3 bg-white/5 text-indigo-400 font-bold rounded-2xl border border-indigo-500/20"
                    >
                      Upload Question Image
                    </button>
                 </div>
               </div>
             ) : (
               <div className="relative w-full aspect-[4/3] max-w-md overflow-hidden rounded-3xl border-2 border-white/20">
                  <div className="absolute top-0 left-0 w-8 h-8 border-t-4 border-l-4 border-indigo-500 rounded-tl-lg" />
                  <div className="absolute top-0 right-0 w-8 h-8 border-t-4 border-r-4 border-indigo-500 rounded-tr-lg" />
                  <div className="absolute bottom-0 left-0 w-8 h-8 border-b-4 border-l-4 border-indigo-500 rounded-bl-lg" />
                  <div className="absolute bottom-0 right-0 w-8 h-8 border-b-4 border-r-4 border-indigo-500 rounded-br-lg" />
                  
                  {isScanning && (
                    <motion.div 
                      animate={{ top: ['0%', '100%', '0%'] }}
                      transition={{ repeat: Infinity, duration: 2, ease: "linear" }}
                      className="absolute inset-x-0 h-0.5 bg-indigo-500 shadow-[0_0_15px_rgba(99,102,241,1)]"
                    />
                  )}
               </div>
             )}
          </div>

          {/* Controls */}
          <div className="p-12 bg-gradient-to-t from-black/80 to-transparent flex flex-col items-center gap-8">
             <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={handleFileUpload} />
             
             {isScanning ? (
               <div className="w-full max-w-xs flex flex-col items-center gap-4">
                  <div className="w-full h-1 bg-white/10 rounded-full overflow-hidden">
                     <div 
                       className="h-full bg-indigo-500 transition-all duration-100" 
                       style={{ width: `${progress}%` }}
                     />
                  </div>
                  <p className="text-indigo-400 font-black text-[10px] uppercase tracking-widest">Analyzing...</p>
               </div>
             ) : (
               <div className="flex items-center gap-12">
                  <button onClick={() => fileInputRef.current?.click()} className="w-12 h-12 rounded-full bg-white/10 flex items-center justify-center text-white">
                     <ImageIcon className="w-6 h-6" />
                  </button>
                  <button onClick={handleScan} className="w-20 h-20 rounded-full border-4 border-white p-1">
                     <div className="w-full h-full rounded-full bg-white flex items-center justify-center text-black">
                        <Scan className="w-8 h-8" />
                     </div>
                  </button>
                  <button className="w-12 h-12 rounded-full bg-white/10 flex items-center justify-center text-white">
                     <Sparkles className="w-6 h-6 text-indigo-400" />
                  </button>
               </div>
             )}
          </div>
        </div>
      </div>
    </div>
  );
}
