import { motion } from "motion/react";
import { useNavigate } from "react-router-dom";
import { ArrowRight, Sparkles, Brain, Rocket, Heart } from "lucide-react";
import { NpcsLogo } from "../components/NpcsLogo";
import { useUser } from "../contexts/UserContext";

export function Welcome() {
  const navigate = useNavigate();
  const { user } = useUser();

  return (
    <div className="min-h-screen bg-[#09090B] text-white font-sans flex flex-col items-center justify-center p-6 md:p-12 relative overflow-hidden">
      {/* Decorative gradients */}
      <div className="absolute top-[-10%] right-[-10%] w-[40%] h-[40%] bg-indigo-500/10 blur-[120px] rounded-full" />
      <div className="absolute bottom-[-10%] left-[-10%] w-[40%] h-[40%] bg-purple-500/10 blur-[120px] rounded-full" />

      <div className="max-w-4xl w-full relative z-10 flex flex-col items-center text-center">
        <motion.div
           initial={{ scale: 0.8, opacity: 0 }}
           animate={{ scale: 1, opacity: 1 }}
           transition={{ duration: 0.6 }}
           className="mb-10"
        >
          <div className="w-24 h-24 rounded-[32px] bg-brand-gradient flex items-center justify-center text-white shadow-2xl shadow-indigo-600/20">
             <NpcsLogo className="w-12 h-12 text-white" />
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <h1 className="text-5xl md:text-7xl font-black mb-6 tracking-tight leading-[1.1]">
            Welcome to the <br />
            <span className="bg-brand-gradient bg-clip-text text-transparent">Future of Learning</span>
          </h1>
          <p className="text-gray-400 text-xl md:text-2xl font-medium max-w-2xl mx-auto mb-12 leading-relaxed">
            Hey <span className="text-indigo-400 font-black">{user?.firstName || "Explorer"}</span>! You're now a part of NPCs Incorporation, where intelligence meets education.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 w-full max-w-3xl mb-16">
           <motion.div
             initial={{ opacity: 0, x: -20 }}
             animate={{ opacity: 1, x: 0 }}
             transition={{ delay: 0.4 }}
             className="p-8 bg-[#18181B] rounded-[40px] border border-white/5 flex flex-col items-start text-left relative overflow-hidden group hover:bg-white/5 transition-all"
           >
              <div className="w-14 h-14 rounded-2xl bg-indigo-500/10 flex items-center justify-center text-indigo-400 mb-6 shadow-sm">
                 <Rocket className="w-7 h-7" />
              </div>
              <h3 className="text-2xl font-black text-white mb-3">NPCs Inc.</h3>
              <p className="text-gray-500 font-bold text-sm leading-relaxed mb-6">
                Redefining digital ecosystems through innovation and empathetic AI technology.
              </p>
              <div className="flex items-center gap-2 text-indigo-400 font-black text-xs uppercase tracking-widest">
                 <Sparkles className="w-4 h-4" /> Innovate. Educate. Elevate.
              </div>
           </motion.div>

           <motion.div
             initial={{ opacity: 0, x: 20 }}
             animate={{ opacity: 1, x: 0 }}
             transition={{ delay: 0.5 }}
             className="p-8 bg-[#18181B] rounded-[40px] border border-white/5 flex flex-col items-start text-left relative overflow-hidden group hover:bg-white/5 transition-all"
           >
              <div className="w-14 h-14 rounded-2xl bg-purple-500/10 flex items-center justify-center text-purple-400 mb-6 shadow-sm">
                 <span className="font-black text-xl">SB</span>
              </div>
              <h3 className="text-2xl font-black text-white mb-3">STUDYBROODY</h3>
              <p className="text-gray-500 font-bold text-sm leading-relaxed mb-6">
                 Your personalized AI study buddy designed for limitless learning, 24/7.
              </p>
              <div className="flex items-center gap-2 text-purple-400 font-black text-xs uppercase tracking-widest">
                 <Brain className="w-4 h-4" /> Smart. Kinder. Brighter.
              </div>
           </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.7 }}
          className="flex flex-col items-center gap-6"
        >
          <button
            onClick={() => navigate("/home")}
            className="px-12 py-5 bg-indigo-600 text-white font-black rounded-[24px] text-xl flex items-center justify-center gap-4 shadow-2xl shadow-indigo-600/20 hover:scale-[1.05] transition-all group"
          >
            Launch Product Hub
            <ArrowRight className="w-6 h-6 group-hover:translate-x-1 transition-transform" />
          </button>
          <p className="text-gray-500 font-bold flex items-center gap-2">
            Let's build a brighter future <Heart className="w-5 h-5 text-rose-500 fill-rose-500/20" />
          </p>
        </motion.div>
      </div>

      {/* Floating character illustration */}
      <motion.div
        animate={{ y: [0, -20, 0], rotate: [0, 5, 0] }}
        transition={{ repeat: Infinity, duration: 6 }}
        className="hidden xl:block absolute top-[20%] right-[10%] w-64 h-64 opacity-20 pointer-events-none"
      >
         <img src="https://api.dicebear.com/7.x/adventurer/svg?seed=Aneka" alt="Character" className="w-full h-full" />
      </motion.div>
      
      <motion.div
        animate={{ y: [0, 20, 0], rotate: [0, -5, 0] }}
        transition={{ repeat: Infinity, duration: 5, delay: 1 }}
        className="hidden xl:block absolute bottom-[15%] left-[10%] w-48 h-48 opacity-20 pointer-events-none"
      >
         <img src="https://api.dicebear.com/7.x/adventurer/svg?seed=Felix" alt="Character" className="w-full h-full" />
      </motion.div>
    </div>
  );
}
