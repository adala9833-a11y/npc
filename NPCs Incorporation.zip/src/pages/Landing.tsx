import { motion } from "motion/react";
import { Link, useNavigate } from "react-router-dom";
import { 
  ArrowRight, Sparkles, Brain, GraduationCap, Shield, 
  Globe, Zap, MessageSquare, BookOpen, PenTool, 
  TrendingUp, FileText, Mic, CheckCircle2, Heart, Rocket
} from "lucide-react";
import { NpcsLogo } from "../components/NpcsLogo";
import { PaperPlaneAnimation } from "../components/PaperPlaneAnimation";

export function Landing() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-[#09090B] text-[#FAFAFA] font-sans selection:bg-indigo-500/30 overflow-x-hidden">
      {/* Navigation Header */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-[#09090B]/80 backdrop-blur-md border-b border-white/5">
        <div className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <NpcsLogo className="w-12 h-12 text-indigo-400" />
            <div className="flex flex-col">
              <span className="text-[18px] font-extrabold tracking-tight text-white leading-none">NPCs Incorporation</span>
              <span className="text-[10px] uppercase tracking-[0.2em] font-bold text-gray-500 mt-1">
                <span className="text-indigo-400">Innovate.</span> <span className="text-amber-400">Educate.</span> <span className="text-emerald-400">Elevate.</span>
              </span>
            </div>
          </div>
          
          <div className="hidden md:flex items-center gap-8">
            <a href="#" className="text-sm font-semibold text-indigo-400 border-b-2 border-indigo-400 pb-1">Home</a>
            <a href="#products" className="text-sm font-semibold text-gray-400 hover:text-indigo-400 transition-colors">Products</a>
            <a href="#vision" className="text-sm font-semibold text-gray-400 hover:text-indigo-400 transition-colors">Tools</a>
            <a href="#about" className="text-sm font-semibold text-gray-400 hover:text-indigo-400 transition-colors">About Us</a>
            <a href="#contact" className="text-sm font-semibold text-gray-400 hover:text-indigo-400 transition-colors">Contact</a>
          </div>

          <div className="flex items-center gap-4">
            <button 
              onClick={() => navigate('/home')}
              className="px-6 py-2.5 rounded-full text-sm font-bold text-indigo-600 bg-indigo-50 hover:bg-indigo-100 transition-all flex items-center gap-2"
            >
              <Shield className="w-4 h-4" /> Sign In
            </button>
            <button 
              onClick={() => navigate('/signup')}
              className="px-6 py-2.5 bg-indigo-600 rounded-full text-sm font-bold text-white shadow-lg shadow-indigo-200 hover:scale-105 transition-all flex items-center gap-2"
            >
              <Zap className="w-4 h-4 fill-white" /> Sign Up
            </button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="pt-32 pb-20 px-6 bg-[#09090B] relative overflow-hidden">
        <PaperPlaneAnimation />
        {/* Background blobs */}
        <div className="absolute top-20 right-[-5%] w-[400px] h-[400px] bg-indigo-500/10 blur-[100px] rounded-full" />
        <div className="absolute bottom-10 left-[-5%] w-[300px] h-[300px] bg-purple-500/10 blur-[80px] rounded-full" />

        <div className="max-w-7xl mx-auto grid lg:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h1 className="text-6xl md:text-7xl font-black text-white mb-6 leading-tight tracking-tight">
              One Platform.<br />
              Limitless Learning.<br />
              <span className="text-indigo-400 border-b-[6px] border-indigo-500/30">For Everyone.</span>
            </h1>
            <div className="flex items-center gap-2 mb-6">
              <Sparkles className="w-5 h-5 text-indigo-400" />
              <p className="text-indigo-400 font-black uppercase tracking-widest text-xs">Reimagining Education with Intelligence.</p>
            </div>
            <p className="text-gray-400 text-lg md:text-xl max-w-lg mb-10 leading-relaxed font-medium">
              NPCs Incorporation builds AI-powered solutions that understand students, support teachers, and transform the future of education in India.
            </p>
            
            <div className="flex flex-wrap gap-4 mb-12">
              <button 
                onClick={() => navigate('/home')}
                className="px-8 py-4 bg-indigo-500 text-white font-bold rounded-2xl text-lg flex items-center gap-3 shadow-xl shadow-indigo-500/20 hover:scale-[1.02] transition-all group"
              >
                <Rocket className="w-6 h-6" /> Access Tools <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </button>
              <button 
                className="px-8 py-4 bg-white/5 border-2 border-white/5 text-gray-300 font-bold rounded-2xl text-lg flex items-center gap-3 hover:bg-white/10 transition-all"
              >
                <Zap className="w-6 h-6 text-purple-400" /> Explore Products
              </button>
            </div>

            <div className="flex gap-8">
              <div className="p-4 bg-white/5 rounded-3xl border border-white/5 shadow-sm flex items-center gap-4 hover:bg-white/10 transition-all">
                <div className="w-12 h-12 rounded-2xl bg-indigo-500/10 flex items-center justify-center text-indigo-400">
                  <Shield className="w-6 h-6" />
                </div>
                <div>
                  <h4 className="font-bold text-gray-400 text-sm">Made for</h4>
                  <p className="font-black text-indigo-400 text-lg leading-none">Students</p>
                  <p className="text-[10px] font-bold text-indigo-500/60 mt-1">Learn Smarter</p>
                </div>
              </div>
              <div className="p-4 bg-white/5 rounded-3xl border border-white/5 shadow-sm flex items-center gap-4 hover:bg-white/10 transition-all">
                <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 flex items-center justify-center text-emerald-400">
                  <GraduationCap className="w-6 h-6" />
                </div>
                <div>
                  <h4 className="font-bold text-gray-400 text-sm">Built for</h4>
                  <p className="font-black text-emerald-400 text-lg leading-none">Teachers</p>
                  <p className="text-[10px] font-bold text-emerald-500/60 mt-1">Teach Better</p>
                </div>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="relative"
          >
            {/* Visual representation of the dashboard from image 1 */}
            <div className="relative bg-[#18181B] rounded-[40px] shadow-2xl p-4 border border-white/5 overflow-hidden">
               <img 
                 src="https://images.unsplash.com/photo-1516321318423-f06f85e504b3?q=80&w=1200&auto=format&fit=crop" 
                 alt="Dashboard Interface" 
                 className="w-full h-auto rounded-[32px] opacity-10 filter grayscale invert"
               />
               <div className="absolute inset-0 flex flex-col p-8 bg-gradient-to-br from-black/60 via-black/20 to-transparent">
                  <div className="flex items-center gap-2 mb-8">
                    <div className="w-8 h-8 rounded-lg bg-indigo-500 flex items-center justify-center text-white font-black text-xs">SB</div>
                    <span className="font-black text-white tracking-tight">STUDYBROODY</span>
                  </div>
                  <div className="space-y-4">
                    <div className="w-[80%] h-4 bg-white/5 rounded-full" />
                    <div className="w-[60%] h-4 bg-white/5 rounded-full" />
                    <div className="w-[90%] h-32 bg-indigo-500/5 rounded-3xl border border-indigo-500/10 mt-8 relative p-6">
                       <div className="flex items-center gap-3">
                         <div className="w-10 h-10 rounded-full bg-indigo-500/20" />
                         <div className="space-y-1">
                            <div className="w-24 h-3 bg-indigo-500/40 rounded-full" />
                            <div className="w-16 h-2 bg-indigo-500/20 rounded-full" />
                         </div>
                       </div>
                    </div>
                  </div>
               </div>
            </div>
            
            {/* Floating avatars or icons from design */}
            <motion.div 
              animate={{ y: [0, -10, 0] }} 
              transition={{ repeat: Infinity, duration: 3 }}
              className="absolute -top-10 -right-10 w-40 h-40 rounded-full p-4 bg-[#1C1C1F] shadow-2xl border border-white/5 flex items-center justify-center"
            >
               <img src="https://api.dicebear.com/7.x/adventurer/svg?seed=Felix" alt="Student" className="w-full h-full" />
            </motion.div>
            <motion.div 
              animate={{ y: [0, 10, 0] }} 
              transition={{ repeat: Infinity, duration: 4, delay: 1 }}
              className="absolute bottom-20 -left-10 w-32 h-32 rounded-full p-4 bg-[#1C1C1F] shadow-2xl border border-white/5 flex items-center justify-center"
            >
               <img src="https://api.dicebear.com/7.x/adventurer/svg?seed=Aneka" alt="Teacher" className="w-full h-full" />
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* Tools Section */}
      <section className="py-24 px-6 bg-[#09090B] border-y border-white/5">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-extrabold text-white mb-4 tracking-tight flex items-center justify-center gap-3">
              <Sparkles className="w-8 h-8 text-amber-500" /> Powerful Tools for Smarter Learning & Teaching <Sparkles className="w-8 h-8 text-purple-400" />
            </h2>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6">
            {[
              { icon: MessageSquare, title: "AI Doubt Solver", desc: "Get instant, accurate answers to any academic question.", bg: "bg-blue-500/10", text: "text-blue-400" },
              { icon: FileText, title: "Quiz Generator", desc: "Auto-generate quizzes, tests & practice sets.", bg: "bg-emerald-500/10", text: "text-emerald-400" },
              { icon: BookOpen, title: "Study Notes", desc: "Smart notes & summaries in seconds.", bg: "bg-amber-500/10", text: "text-amber-400" },
              { icon: TrendingUp, title: "Personalized Paths", desc: "AI creates learning paths that adapt to your progress.", bg: "bg-indigo-500/10", text: "text-indigo-400" },
              { icon: PenTool, title: "Assignment Evaluator", desc: "Automatic grading with feedback for teachers.", bg: "bg-purple-500/10", text: "text-purple-400" },
              { icon: Mic, title: "Voice AI Tutor", desc: "Learn by speaking with your AI best friend.", bg: "bg-rose-500/10", text: "text-rose-400" },
            ].map((tool) => (
              <div
                key={tool.title}
                className="flex flex-col items-center text-center p-6 rounded-[32px] bg-[#18181B] border border-white/5 transition-all cursor-pointer group"
              >
                <div className={`w-16 h-16 rounded-2xl ${tool.bg} ${tool.text} flex items-center justify-center mb-6 shadow-sm group-hover:scale-110 transition-transform`}>
                  <tool.icon className="w-8 h-8" />
                </div>
                <h3 className="font-black text-white text-[15px] mb-3 leading-tight tracking-tight">{tool.title}</h3>
                <p className="text-[11px] text-gray-500 font-medium leading-relaxed">{tool.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-24 px-6 bg-[#09090B]">
        <div className="max-w-7xl mx-auto grid md:grid-cols-2 gap-8 pb-12">
           <motion.div 
             initial={{ opacity: 0, x: -20 }}
             whileInView={{ opacity: 1, x: 0 }}
             viewport={{ once: true }}
             className="bg-[#18181B] rounded-[40px] p-10 border border-white/5 shadow-2xl relative overflow-hidden group"
           >
              <div className="absolute top-8 left-8 w-12 h-12 rounded-2xl bg-indigo-500/10 text-indigo-400 flex items-center justify-center opacity-20 group-hover:opacity-100 transition-opacity">
                <Shield className="w-6 h-6" />
              </div>
              <div className="pl-16">
                 <h2 className="text-3xl font-black text-white mb-6">About NPCs Incorporation</h2>
                 <p className="text-gray-400 font-medium mb-8 leading-relaxed">
                   Founded in <span className="text-indigo-400 font-bold">2026, NPCs Inc.</span> is a mission-driven company working to solve real problems in the Indian education system through innovation, empathy and technology.
                 </p>
                 <div className="space-y-4">
                    {[
                      "We understand the challenges students & teachers face.",
                      "We build practical, scalable & affordable solutions.",
                      "We empower both students and teachers.",
                      "We are committed to a better future for India."
                    ].map((text, i) => (
                      <div key={i} className="flex items-center gap-3 text-[14px] font-bold text-gray-300">
                        <CheckCircle2 className="w-5 h-5 text-indigo-500 fill-indigo-500/10" />
                        {text}
                      </div>
                    ))}
                 </div>
                 
                 <div className="mt-12 p-6 bg-indigo-500/5 rounded-[28px] border border-indigo-500/10 flex items-center gap-4 relative">
                    <Heart className="w-8 h-8 text-rose-500 fill-rose-500/10 absolute -top-4 -right-4 rotate-12" />
                    <div className="w-12 h-12 rounded-full bg-white/5 flex items-center justify-center shadow-md shrink-0">
                      <Heart className="w-6 h-6 text-indigo-400" />
                    </div>
                    <p className="text-[14px] font-black text-indigo-200">
                       Our vision is simple: <span className="text-indigo-400">Make quality education personalized, accessible & enjoyable for all.</span>
                    </p>
                 </div>
              </div>
           </motion.div>

           <motion.div 
             initial={{ opacity: 0, x: 20 }}
             whileInView={{ opacity: 1, x: 0 }}
             viewport={{ once: true }}
             className="bg-emerald-500/5 rounded-[40px] p-10 border border-emerald-500/10 shadow-2xl relative overflow-hidden"
           >
              <div className="absolute top-8 left-8 w-12 h-12 rounded-2xl bg-[#09090B] text-indigo-400 flex items-center justify-center shadow-sm">
                <span className="font-black">SB</span>
              </div>
              <div className="pl-16">
                 <h2 className="text-3xl font-black text-white mb-6">About STUDYBROODY</h2>
                 <p className="text-gray-400 font-medium mb-8 leading-relaxed">
                   <span className="text-indigo-400 font-black">STUDYBROODY (SB)</span> is our flagship AI-powered assistant designed to support every learner and educator.
                 </p>
                 <div className="space-y-4">
                    {[
                      { icon: Shield, text: "Available 24x7 - Anytime, Anywhere" },
                      { icon: Brain, text: "Built with advanced AI, LLMs & Knowledge Graphs" },
                      { icon: GraduationCap, text: "Supports Students with smarter learning" },
                      { icon: Zap, text: "Empowers Teachers with smart automation" },
                      { icon: Globe, text: "Safe, reliable & made for India" },
                    ].map((item, i) => (
                      <div key={i} className="flex items-center gap-3 text-[14px] font-bold text-gray-300">
                        <item.icon className="w-5 h-5 text-gray-600" />
                        {item.text}
                      </div>
                    ))}
                 </div>

                 <div className="mt-12 space-y-2">
                    <p className="text-[16px] font-black text-emerald-100 leading-none">One App. Infinite Possibilities.</p>
                    <p className="text-[14px] font-black text-emerald-400">For Students. For Teachers. For Everyone.</p>
                 </div>
                 
                 <div className="absolute bottom-8 right-8">
                    <motion.div
                      animate={{ rotate: [0, 10, 0], y: [0, -5, 0] }}
                      transition={{ repeat: Infinity, duration: 4 }}
                    >
                      <Rocket className="w-12 h-12 text-amber-500 fill-amber-500/10" />
                    </motion.div>
                 </div>
              </div>
           </motion.div>
        </div>

        {/* STUDYBROODY ID Card Mockup */}
        <div className="max-w-4xl mx-auto mt-20 p-12 bg-[#18181B] rounded-[48px] border-2 border-dashed border-white/5 shadow-2xl relative">
           <div className="grid md:grid-cols-[1.5fr_1fr] gap-12 items-center">
              <div>
                 <div className="flex items-center gap-4 mb-4">
                    <div className="w-20 h-20 rounded-full bg-brand-gradient flex items-center justify-center text-white font-black text-4xl shadow-2xl">SB</div>
                    <div>
                       <h3 className="text-3xl font-black text-white tracking-tight">STUDYBROODY ID (SB ID)</h3>
                       <p className="text-gray-500 font-bold">Your unique learning identity across the platform.</p>
                    </div>
                 </div>
                 <div className="flex gap-6 mt-8">
                    {[
                      { icon: Shield, label: "Secure", color: "text-emerald-400" },
                      { icon: GraduationCap, label: "Personalized", color: "text-blue-400" },
                      { icon: TrendingUp, label: "Track Progress", color: "text-indigo-400" },
                      { icon: Sparkles, label: "Earn Badges", color: "text-amber-400" },
                    ].map((item, i) => (
                      <div key={i} className="flex flex-col items-center gap-2">
                        <div className={`w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center ${item.color}`}>
                           <item.icon className="w-5 h-5" />
                        </div>
                        <span className="text-[10px] font-black text-gray-500 uppercase">{item.label}</span>
                      </div>
                    ))}
                 </div>
              </div>

              <div className="bg-[#09090B] border border-white/5 rounded-[32px] p-6 shadow-2xl flex flex-col gap-4 relative overflow-hidden">
                 <div className="flex justify-between items-start">
                    <span className="text-[10px] font-black text-gray-600 uppercase tracking-widest">Your STUDYBROODY ID</span>
                    <CheckCircle2 className="w-5 h-5 text-indigo-400" />
                 </div>
                 <div className="flex items-center gap-4">
                    <div className="w-16 h-16 rounded-full overflow-hidden border-2 border-indigo-500/20">
                       <img src="https://api.dicebear.com/7.x/avataaars/svg?seed=Aarav" alt="Profile" />
                    </div>
                    <div>
                       <h4 className="text-xl font-black text-white leading-none">SB-2026-000123</h4>
                       <p className="text-[11px] font-bold text-indigo-400 mt-1 uppercase tracking-wider">Learner • Explorer • Achiever</p>
                    </div>
                 </div>
                 <div className="h-6 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-10 mt-2" />
              </div>
           </div>
        </div>

        <div className="text-center mt-24">
           <h2 className="text-3xl md:text-4xl font-black text-white mb-8">
             Let's Build a Smarter, Kinder & Brighter Education Together! <Heart className="inline w-10 h-10 text-indigo-400 fill-indigo-500/10 align-middle" />
           </h2>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-20 px-6 bg-[#09090B] border-t border-white/5">
        <div className="max-w-7xl mx-auto grid md:grid-cols-4 gap-12 text-center md:text-left">
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center gap-3 justify-center md:justify-start mb-6">
              <NpcsLogo className="w-10 h-10 text-indigo-400" />
              <span className="text-xl font-black text-white tracking-tight">NPCs Incorporation</span>
            </div>
            <p className="text-gray-500 font-medium max-w-sm mb-8">
              Pioneering intelligent solutions to re-architect global learning ecosystems for the next generation.
            </p>
          </div>
          <div>
            <h4 className="font-black text-white uppercase text-xs tracking-widest mb-6">Quick Links</h4>
            <div className="space-y-4 flex flex-col">
              <a href="#" className="text-gray-500 font-bold hover:text-indigo-400 transition-colors">Home</a>
              <a href="#" className="text-gray-500 font-bold hover:text-indigo-400 transition-colors">Products</a>
              <a href="#" className="text-gray-500 font-bold hover:text-indigo-400 transition-colors">Vision</a>
              <a href="#" className="text-gray-400 font-bold hover:text-indigo-600 transition-colors">Contact</a>
            </div>
          </div>
          <div>
            <h4 className="font-black text-white uppercase text-xs tracking-widest mb-6">Legal</h4>
            <div className="space-y-4 flex flex-col">
              <Link to="/about" className="text-gray-500 font-bold hover:text-indigo-400 transition-colors">Privacy Policy</Link>
              <Link to="/about" className="text-gray-500 font-bold hover:text-indigo-400 transition-colors">Terms of Service</Link>
              <Link to="/updates" className="text-gray-500 font-bold hover:text-indigo-400 transition-colors">Cookie Policy</Link>
            </div>
          </div>
        </div>
        <div className="max-w-7xl mx-auto mt-20 pt-8 border-t border-white/5 flex flex-col items-center gap-4">
           <p className="text-xs font-bold text-gray-600 tracking-widest uppercase">© 2026 NPCs Incorporation. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}
