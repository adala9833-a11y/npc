import { Link } from "react-router-dom";
import { BookOpen, GraduationCap, Map as MapIcon, BarChart2, MessageSquare, ArrowLeft } from "lucide-react";
import { cn } from "../../lib/utils";

const sbNavItems = [
  { icon: GraduationCap, label: "Dashboard", id: "dashboard" },
  { icon: MapIcon, label: "Journey Map", id: "journey" },
  { icon: BarChart2, label: "Stats & XP", id: "stats" },
  { icon: MessageSquare, label: "SB Chat", id: "chat", mobileOnly: true },
];

export function StudyBroodyLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex h-screen bg-[#09090B] text-[#E4E4E7] font-sans overflow-hidden">
      {/* SB Sidebar */}
      <div className="w-64 h-full bg-[#121214] flex flex-col shrink-0 border-r border-[#ffffff14]">
        <div className="p-6">
          <Link to="/home" className="inline-flex items-center gap-2 text-[#71717A] hover:text-[#E4E4E7] transition-colors text-sm mb-6 font-medium">
            <ArrowLeft className="w-4 h-4" /> Back to NPCs Hub
          </Link>

          <div className="flex items-center gap-3">
             <div className="w-12 h-12 rounded-xl bg-accent-gradient flex items-center justify-center p-[2px] shadow-[0_0_15px_rgba(99,102,241,0.2)]">
               <div className="w-full h-full bg-[#121214] rounded-xl flex items-center justify-center">
                 <span className="text-[20px] font-black tracking-tighter leading-none text-white shadow-sm">SB</span>
               </div>
             </div>
             <div>
               <h1 className="text-[#E4E4E7] font-bold text-lg tracking-tight leading-tight">STUDYBROODY</h1>
               <p className="text-xs text-[#A855F7] font-medium">Companion v2.1</p>
             </div>
          </div>
        </div>

        <nav className="flex-1 py-4 px-4 space-y-1">
          {sbNavItems.map((item) => (
            <button
               key={item.id}
               className={cn(
                 "w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200",
                 item.id === "dashboard" 
                  ? "bg-[#ffffff0d] text-[#A855F7] font-medium" 
                  : "text-[#71717A] hover:bg-[#ffffff08] hover:text-[#E4E4E7]"
               )}
            >
               <item.icon className="w-5 h-5 opacity-80" />
               <span>{item.label}</span>
            </button>
          ))}
        </nav>

        {/* User Mini Profile */}
        <div className="p-4 border-t border-[#ffffff14] m-4 rounded-xl bg-[#ffffff05]">
           <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-semibold text-[#E4E4E7]">Current Streak</p>
                <p className="text-2xl font-black text-amber-500">12<span className="text-sm font-semibold text-amber-500/50">🔥</span></p>
              </div>
           </div>
        </div>
      </div>

      <div className="flex-1 flex overflow-hidden">
         {children}
      </div>
    </div>
  );
}
