import { BookOpen, Trophy, Clock, Star, Zap, Map as MapIcon } from "lucide-react";
import { motion } from "motion/react";

export function StudyBroodyDashboard() {
  return (
    <div className="flex-1 overflow-y-auto bg-[#09090B]">
      <div className="max-w-5xl mx-auto p-8">
        
        <header className="mb-8">
           <h2 className="text-[32px] font-bold text-[#E4E4E7] tracking-[-0.03em]">Welcome back, Admin!</h2>
           <p className="text-[#71717A] mt-1 text-[16px]">You're making great progress. Let's keep the momentum going.</p>
        </header>

        {/* Stats Row */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
           {[
             { label: "Total XP", value: "2,450", icon: Star, color: "text-amber-400", bg: "bg-[#18181B]" },
             { label: "Hours Learned", value: "32.5", icon: Clock, color: "text-[#6366F1]", bg: "bg-[#18181B]" },
             { label: "Quizzes Passed", value: "18", icon: Trophy, color: "text-[#4ADE80]", bg: "bg-[#18181B]" },
             { label: "Active Streak", value: "12 Days", icon: Zap, color: "text-[#A855F7]", bg: "bg-[#18181B]" },
           ].map((stat, i) => (
             <motion.div 
               key={i}
               initial={{ opacity: 0, y: 20 }}
               animate={{ opacity: 1, y: 0 }}
               transition={{ delay: i * 0.1 }}
               className="bg-[#18181B] border border-[#ffffff14] p-5 rounded-2xl shadow-sm flex items-center gap-4"
             >
                <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${stat.color} bg-[#ffffff0d]`}>
                  <stat.icon className="w-6 h-6" />
                </div>
                <div>
                   <p className="text-[13px] font-semibold text-[#71717A]">{stat.label}</p>
                   <p className="text-[18px] font-bold text-[#E4E4E7]">{stat.value}</p>
                </div>
             </motion.div>
           ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
           <div className="lg:col-span-2 space-y-8">
              {/* Main Learning Module */}
              <div className="bg-hero-gradient border-accent-gradient rounded-3xl p-8 text-[#E4E4E7] relative overflow-hidden">
                 <div className="absolute top-0 right-0 w-64 h-64 bg-[#A855F7]/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2" />
                 
                 <div className="relative z-10">
                    <span className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#A855F7]/10 font-semibold text-xs text-[#A855F7] border border-[#A855F7]/20 mb-4 tracking-wider uppercase">
                       <BookOpen className="w-4 h-4" /> Recommended Next
                    </span>
                    <h3 className="text-3xl font-bold mb-2">Advanced Artificial Intelligence</h3>
                    <p className="text-[#71717A] text-lg mb-8 max-w-xl">Deep dive into neural networks, backpropagation, and transformer architectures.</p>
                    
                    <button className="bg-accent-gradient text-white px-6 py-3 rounded-xl font-semibold shadow-lg transition-transform hover:scale-105">
                      Resume Module
                    </button>
                 </div>
              </div>

              {/* Journey Map Preview */}
              <div className="bg-[#18181B] rounded-3xl p-6 border border-[#ffffff14] shadow-sm">
                <h3 className="text-xl font-bold text-[#E4E4E7] mb-4">Your Journey Map</h3>
                <div className="h-48 border border-dashed border-[#ffffff14] rounded-xl flex flex-col items-center justify-center text-[#71717A]">
                   <MapIcon className="w-8 h-8 mb-2 opacity-50" />
                   <p className="font-medium text-[14px]">Journey Map visualization goes here</p>
                </div>
              </div>
           </div>

           <div className="space-y-8">
              {/* Recent Activity */}
              <div className="bg-[#18181B] rounded-3xl p-6 border border-[#ffffff14] shadow-sm h-full flex flex-col">
                 <h3 className="text-lg font-bold text-[#E4E4E7] mb-4">Recent Activity</h3>
                 <div className="space-y-6">
                    {[
                      { title: "Completed: Intro to ML", time: "2 hours ago", type: "success" },
                      { title: "Quiz: Data Structures", time: "5 hours ago", type: "info" },
                      { title: "Started: React Basics", time: "1 day ago", type: "neutral" }
                    ].map((act, i) => (
                      <div key={i} className="flex gap-4">
                         <div className="w-10 h-10 rounded-full bg-[#09090B] border border-[#ffffff14] flex items-center justify-center shrink-0">
                           <div className={`w-2.5 h-2.5 rounded-full ${act.type === 'success' ? 'bg-[#4ADE80]' : act.type === 'info' ? 'bg-[#6366F1]' : 'bg-[#71717A]'}`} />
                         </div>
                         <div>
                            <p className="font-semibold text-[#E4E4E7] text-sm">{act.title}</p>
                            <p className="text-xs text-[#71717A]">{act.time}</p>
                         </div>
                      </div>
                    ))}
                 </div>
              </div>
           </div>
        </div>
      </div>
    </div>
  );
}
