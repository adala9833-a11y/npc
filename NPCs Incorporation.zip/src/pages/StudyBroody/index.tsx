import { Outlet } from "react-router-dom";
import { StudyBroodyLayout } from "./Layout";
import { StudyBroodyDashboard } from "./Dashboard";
import { Chatbot } from "./Chatbot";

export function StudyBroodyApp() {
  return (
    <StudyBroodyLayout>
       {/* Main Content Area */}
       <StudyBroodyDashboard />
       
       {/* The Chatbot Panel always visible on the right */}
       <Chatbot />
    </StudyBroodyLayout>
  );
}
