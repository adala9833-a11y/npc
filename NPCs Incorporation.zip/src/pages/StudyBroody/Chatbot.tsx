import { useState, useRef, useEffect } from "react";
import { Send, Bot, User, Loader2, Sparkles, Mic } from "lucide-react";
import ReactMarkdown from "react-markdown";
import { GoogleGenAI } from "@google/genai";
import { motion, AnimatePresence } from "motion/react";
import { cn } from "../../lib/utils";

// Try to initialize Gemini. Will fail safely if key is missing and show error in chat.
let ai: GoogleGenAI | null = null;
try {
  if (process.env.GEMINI_API_KEY) {
    ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
  }
} catch (e) {
  console.error("Failed to initialize Gemini:", e);
}

type Message = {
  id: string;
  role: "user" | "model";
  content: string;
};

const SUGGESTED_PROMPTS = [
  "Explain quantum computing",
  "Generate a quick quiz on React",
  "Summarize my learning progress",
];

export function Chatbot() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      role: "model",
      content: "Hi! 👋 I'm STUDYBROODY. Let's learn smarter today. What would you like to explore?",
    },
  ]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading]);

  const handleSubmit = async (text: string) => {
    if (!text.trim() || isLoading) return;

    const userMessage = text.trim();
    setInput("");
    setMessages((prev) => [
      ...prev,
      { id: Date.now().toString(), role: "user", content: userMessage },
    ]);
    setIsLoading(true);

    if (!ai) {
      setMessages((prev) => [
        ...prev,
        {
          id: (Date.now() + 1).toString(),
          role: "model",
          content: "I'm sorry, my AI brain isn't connected right now. Please configure the GEMINI_API_KEY.",
        },
      ]);
      setIsLoading(false);
      return;
    }

    try {
      // Build conversation history for context (basic implementation)
      const formattedHistory = messages.map(m => `${m.role === 'user' ? 'User' : 'Assistant'}: ${m.content}`).join('\n');
      const prompt = `Conversation history:\n${formattedHistory}\n\nUser: ${userMessage}\nAssistant:`;

      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: prompt,
        config: {
          systemInstruction: "You are STUDYBROODY, a friendly, intelligent, and encouraging AI learning companion for NPCs Inc. Keep your answers concise, structured, and helpful. Use formatting like bullet points when appropriate.",
        }
      });
      
      const responseText = response.text || "I'm not sure how to respond to that.";
      
      setMessages((prev) => [
        ...prev,
        { id: Date.now().toString(), role: "model", content: responseText },
      ]);
    } catch (error) {
      console.error("Chat error:", error);
      setMessages((prev) => [
        ...prev,
        {
          id: Date.now().toString(),
          role: "model",
          content: "Oops! I encountered an error. Please try again.",
        },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="w-[400px] h-full bg-[#18181B] border-l border-[#ffffff14] flex flex-col shrink-0 shadow-2xl relative z-20">
      {/* Chatbot Header */}
      <div className="p-4 border-b border-[#ffffff14] flex items-center justify-between bg-[#18181B] z-10">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-accent-gradient flex items-center justify-center text-white">
            <Sparkles className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-bold text-[#E4E4E7] leading-tight">STUDYBROODY</h3>
            <p className="text-xs text-[#4ADE80] font-medium flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-[#4ADE80] animate-pulse" /> Online
            </p>
          </div>
        </div>
      </div>

      {/* Messages Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-6">
        <AnimatePresence initial={false}>
          {messages.map((msg) => (
            <motion.div
              key={msg.id}
              initial={{ opacity: 0, y: 10, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              className={cn(
                "flex gap-3 max-w-[90%]",
                msg.role === "user" ? "ml-auto flex-row-reverse" : "mr-auto"
              )}
            >
              <div
                className={cn(
                  "w-8 h-8 rounded-full flex items-center justify-center shrink-0 border",
                  msg.role === "user"
                    ? "bg-[#27272A] border-[#ffffff14] text-[#E4E4E7]"
                    : "bg-accent-gradient border-transparent text-white"
                )}
              >
                {msg.role === "user" ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
              </div>
              
              <div
                className={cn(
                  "rounded-2xl px-4 py-3 text-[14px] shadow-sm",
                  msg.role === "user"
                    ? "bg-[#27272A] text-[#E4E4E7] rounded-tr-sm border border-[#ffffff14]"
                    : "bg-[#09090B] border border-[#ffffff14] text-[#E4E4E7] rounded-tl-sm markdown-body"
                )}
              >
                {msg.role === "user" ? (
                  msg.content
                ) : (
                  <ReactMarkdown>{msg.content}</ReactMarkdown>
                )}
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
        
        {isLoading && (
          <motion.div
             initial={{ opacity: 0, y: 10 }}
             animate={{ opacity: 1, y: 0 }}
             className="flex gap-3 max-w-[80%] mr-auto"
          >
             <div className="w-8 h-8 rounded-full border bg-accent-gradient border-transparent text-white flex items-center justify-center shrink-0">
                <Bot className="w-4 h-4" />
             </div>
             <div className="bg-[#09090B] border border-[#ffffff14] rounded-2xl rounded-tl-sm px-4 py-3 text-sm shadow-sm flex items-center gap-2 text-[#71717A]">
               <Loader2 className="w-4 h-4 animate-spin" /> Thinking...
             </div>
          </motion.div>
        )}
        <div ref={messagesEndRef} className="h-1" />
      </div>

      {/* Input Area */}
      <div className="p-4 bg-[#18181B] border-t border-[#ffffff14]">
        <div className="mb-3 flex flex-wrap gap-2">
           {messages.length === 1 && SUGGESTED_PROMPTS.map((prompt, i) => (
              <button 
                key={i}
                onClick={() => handleSubmit(prompt)}
                className="text-xs bg-[#ffffff0d] hover:bg-[#ffffff14] text-[#E4E4E7] font-medium px-3 py-1.5 rounded-full transition-colors border border-[#ffffff14]"
              >
                {prompt}
              </button>
           ))}
        </div>
        
        <form 
          onSubmit={(e) => { e.preventDefault(); handleSubmit(input); }}
          className="relative flex items-center"
        >
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask STUDYBROODY anything..."
            className="w-full bg-[#27272A] border border-[#ffffff14] text-[#E4E4E7] text-sm rounded-xl pl-4 pr-24 py-3.5 focus:outline-none focus:border-[#A855F7] focus:ring-1 focus:ring-[#A855F7]/50 transition-all placeholder:text-[#71717A]"
            disabled={isLoading}
          />
          <div className="absolute right-2 flex items-center gap-1">
             <button
               type="button"
               className="w-8 h-8 rounded-lg flex items-center justify-center text-[#71717A] hover:text-[#E4E4E7] hover:bg-[#ffffff0d] transition-colors"
             >
               <Mic className="w-4 h-4" />
             </button>
             <button
               type="submit"
               disabled={!input.trim() || isLoading}
               className="w-8 h-8 rounded-lg bg-accent-gradient text-white flex items-center justify-center disabled:opacity-50 disabled:cursor-not-allowed transition-colors shadow-sm"
             >
               <Send className="w-4 h-4 translate-x-[-1px] translate-y-[1px]" />
             </button>
          </div>
        </form>
        <div className="text-center mt-3">
          <span className="text-[10px] text-[#71717A]">Powered by Gemini &middot; AI can make mistakes</span>
        </div>
      </div>
    </div>
  );
}
