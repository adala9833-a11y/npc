import { Bell, Sparkles, MessageSquare, Camera, Mic, Send, Bot, User as UserIcon } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { useNavigate, Link } from "react-router-dom";
import { useUser } from "../contexts/UserContext";
import { cn } from "../lib/utils";
import { useState, useRef, useEffect } from "react";
import { askBroody } from "../services/geminiService";

interface ChatMessage {
  role: 'user' | 'assistant';
  content: string;
}

export function Chat() {
  const { user } = useUser();
  const navigate = useNavigate();
  const [input, setInput] = useState("");
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isLoading]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMessage = input;
    setInput("");
    setMessages(prev => [...prev, { role: 'user', content: userMessage }]);
    setIsLoading(true);

    try {
      const history = messages.map(msg => ({
        role: msg.role === 'user' ? 'user' : 'model',
        parts: [{ text: msg.content }]
      }));

      const response = await askBroody(userMessage, history);
      setMessages(prev => [...prev, { role: 'assistant', content: response }]);
    } catch (error) {
      console.error("Chat error:", error);
      setMessages(prev => [...prev, { role: 'assistant', content: "Sorry, I had a bit of a brain freeze. Could you try asking again?" }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex-1 bg-[#09090B] flex flex-col h-screen overflow-hidden">
      {/* Header */}
      <header className="h-20 px-8 flex items-center justify-between bg-[#09090B]/80 backdrop-blur-md z-30 border-b border-white/5 shrink-0">
        <div className="flex items-center gap-3">
           <div className="w-10 h-10 rounded-xl bg-brand-gradient flex items-center justify-center text-white shadow-lg shadow-indigo-600/20">
              <Bot className="w-6 h-6" />
           </div>
           <div>
              <h2 className="font-black text-white leading-none">BROODY AI</h2>
              <p className="text-[10px] font-bold text-gray-500 uppercase tracking-widest mt-1">Active Now</p>
           </div>
        </div>
        <div className="flex items-center gap-4">
           <Link to="/updates" className="w-10 h-10 bg-[#18181B] border border-white/5 rounded-xl flex items-center justify-center text-gray-400 hover:text-indigo-400 transition-colors relative">
              <Bell className="w-5 h-5" />
              <span className="absolute top-2.5 right-2.5 w-2 h-2 bg-rose-500 rounded-full ring-4 ring-[#18181B]" />
           </Link>
           <button 
             onClick={() => setMessages([])}
             className="hidden md:flex items-center gap-2 px-4 py-2 bg-indigo-500/10 text-indigo-400 rounded-xl font-bold text-xs hover:bg-indigo-500/20 transition-all"
           >
             <Sparkles className="w-4 h-4" /> Reset Chat
           </button>
        </div>
      </header>

      <div className="flex-1 overflow-hidden flex flex-col max-w-5xl mx-auto w-full relative">
        {/* Chat Area */}
        <div 
          ref={scrollRef}
          className="flex-1 overflow-y-auto p-6 space-y-6 no-scrollbar"
        >
          {messages.length === 0 && (
            <div className="h-full flex flex-col items-center justify-center text-center max-w-lg mx-auto">
              <div className="w-24 h-24 bg-indigo-500/10 rounded-[32px] flex items-center justify-center text-indigo-400 mb-8 shadow-[0_0_40px_rgba(99,102,241,0.1)] border border-indigo-500/20">
                <MessageSquare className="w-12 h-12" />
              </div>
              <h1 className="text-4xl font-black text-white mb-4 leading-tight tracking-tight">
                Hello, {user?.firstName || "Learner"}! 👋
              </h1>
              <p className="text-gray-500 font-bold text-lg mb-8 leading-relaxed">
                I'm BROODY, your personal study assistant. Ask me anything about your subjects, or try scanning a problem!
              </p>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 w-full">
                {[
                  "Explain Photosynthesis in simple terms",
                  "What are linear equations?",
                  "Help me write a summary of Macbeth",
                  "Tips for staying focused while studying"
                ].map(suggestion => (
                  <button
                    key={suggestion}
                    onClick={() => setInput(suggestion)}
                    className="p-4 bg-[#18181B] border border-white/5 rounded-2xl text-left text-sm font-bold text-gray-400 hover:text-white transition-all border-l-4 border-l-indigo-600 shadow-sm"
                  >
                    {suggestion}
                  </button>
                ))}
              </div>
            </div>
          )}

          <div className="flex flex-col gap-6">
            {messages.map((message, index) => (
              <div
                key={index}
                className={cn(
                  "flex items-start gap-4 max-w-[85%]",
                  message.role === 'user' ? "ml-auto flex-row-reverse" : "mr-auto"
                )}
              >
                <div className={cn(
                  "w-8 h-8 rounded-lg shrink-0 flex items-center justify-center shadow-sm mt-1 ring-2 ring-transparent transition-all",
                  message.role === 'user' ? "bg-indigo-600 text-white" : "bg-[#18181B] border border-white/5 text-indigo-400"
                )}>
                  {message.role === 'user' ? <UserIcon className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
                </div>
                <div className={cn(
                  "p-4 rounded-2xl text-[14px] leading-relaxed font-medium shadow-sm transition-all",
                  message.role === 'user' 
                    ? "bg-indigo-600 text-white rounded-tr-none" 
                    : "bg-[#18181B] border border-white/10 text-gray-200 rounded-tl-none"
                )}>
                  {message.content}
                </div>
              </div>
            ))}
          </div>

          {isLoading && (
            <div className="flex items-start gap-4 max-w-[85%] mr-auto">
              <div className="w-8 h-8 rounded-lg shrink-0 flex items-center justify-center bg-[#18181B] border border-white/5 text-indigo-400 shadow-sm mt-1">
                <Bot className="w-4 h-4 animate-pulse" />
              </div>
              <div className="p-4 rounded-2xl bg-[#18181B] border border-white/10 text-gray-400 rounded-tl-none font-bold text-xs italic flex items-center gap-2">
                BROODY is thinking...
                <motion.span 
                  animate={{ opacity: [0, 1, 0] }} 
                  transition={{ repeat: Infinity, duration: 1.5 }}
                >
                  ✨
                </motion.span>
              </div>
            </div>
          )}
        </div>

        {/* Input Area */}
        <div className="p-6 shrink-0">
           <div className="relative flex items-end gap-3 bg-[#18181B] border border-white/10 rounded-[28px] p-2 shadow-2xl focus-within:border-indigo-500/40 transition-all">
              <div className="flex gap-1 pl-2 pb-2">
                <button 
                  onClick={() => navigate('/camera')}
                  className="w-10 h-10 rounded-full flex items-center justify-center text-gray-400 hover:bg-white/5 hover:text-emerald-400 transition-all group"
                  title="Camera Solver"
                >
                   <Camera className="w-5 h-5 group-hover:scale-110 transition-transform" />
                </button>
                <button 
                  onClick={() => navigate('/voice-assistant')}
                  className="w-10 h-10 rounded-full flex items-center justify-center text-gray-400 hover:bg-white/5 hover:text-purple-400 transition-all group"
                  title="Voice Assistant"
                >
                   <Mic className="w-5 h-5 group-hover:scale-110 transition-transform" />
                </button>
              </div>

              <textarea 
                rows={1}
                value={input}
                onChange={(e) => {
                  setInput(e.target.value);
                  e.target.style.height = 'inherit';
                  e.target.style.height = `${e.target.scrollHeight}px`;
                }}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    handleSend();
                  }
                }}
                placeholder="Ask anything to BROODY..."
                className="flex-1 bg-transparent border-none focus:ring-0 text-white font-bold text-sm py-3 px-2 resize-none max-h-32 no-scrollbar placeholder:text-gray-600"
              />

              <button 
                onClick={handleSend}
                disabled={!input.trim() || isLoading}
                className={cn(
                  "w-12 h-12 rounded-full flex items-center justify-center transition-all shadow-lg shrink-0 mb-1 mr-1",
                  input.trim() && !isLoading 
                    ? "bg-indigo-600 text-white shadow-indigo-600/20 hover:scale-105 active:scale-95" 
                    : "bg-white/5 text-gray-700 cursor-not-allowed"
                )}
              >
                 <Send className="w-5 h-5" />
              </button>
           </div>
           
           <p className="text-[10px] text-center text-gray-600 font-bold mt-4 uppercase tracking-[0.2em]">
             NPCs Incorporation • Built with <Heart className="inline w-3 h-3 text-rose-500 fill-rose-500/20" /> for Indian Students
           </p>
        </div>
      </div>
    </div>
  );
}

function Heart({ className }: { className?: string }) {
  return (
    <svg 
      xmlns="http://www.w3.org/2000/svg" 
      width="24" 
      height="24" 
      viewBox="0 0 24 24" 
      fill="none" 
      stroke="currentColor" 
      strokeWidth="2" 
      strokeLinecap="round" 
      strokeLinejoin="round" 
      className={className}
    >
      <path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z" />
    </svg>
  );
}
