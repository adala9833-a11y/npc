import { Search, Bell, Sparkles, MessageSquare, Camera, LayoutGrid, FileText, CheckCircle2, Mic, Bot } from "lucide-react";
import { motion } from "motion/react";
import { Link, useNavigate } from "react-router-dom";
import { useUser } from "../contexts/UserContext";
import { cn } from "../lib/utils";

export function Home() {
  const { user } = useUser();
  const navigate = useNavigate();

  return (
    <div className="flex-1 bg-[#09090B] overflow-y-auto min-h-screen no-scrollbar relative">
      {/* Search Header */}
      <header className="h-24 px-8 flex items-center justify-between sticky top-0 bg-[#09090B]/80 backdrop-blur-md z-30">
        <div className="flex-1 max-w-xl">
           <div className="relative group">
              <Search className="w-5 h-5 absolute left-5 top-1/2 -translate-y-1/2 text-gray-500 group-focus-within:text-indigo-400 transition-colors" />
              <input 
                type="text" 
                placeholder="Ask anything to BROODY..." 
                onFocus={() => navigate('/chat')}
                className="w-full pl-14 pr-24 py-4 bg-[#18181B] border border-white/5 rounded-[20px] text-sm text-white focus:outline-none focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500/30 transition-all font-bold placeholder:font-medium placeholder:text-gray-600 cursor-pointer"
              />
              
              <div className="absolute right-2 top-1/2 -translate-y-1/2 flex items-center gap-1">
                <button 
                  onClick={() => navigate('/camera')}
                  className="w-8 h-8 rounded-lg flex items-center justify-center text-gray-500 hover:text-emerald-400 transition-colors"
                >
                  <Camera className="w-4 h-4" />
                </button>
                <button 
                  onClick={() => navigate('/voice-assistant')}
                  className="w-8 h-8 rounded-lg flex items-center justify-center text-gray-500 hover:text-purple-400 transition-colors"
                >
                  <Mic className="w-4 h-4" />
                </button>
              </div>
           </div>
        </div>
        <div className="flex items-center gap-4">
           <Link to="/updates" className="w-12 h-12 bg-[#18181B] border border-white/5 rounded-2xl flex items-center justify-center text-gray-400 hover:text-indigo-400 relative">
              <Bell className="w-5 h-5" />
              <span className="absolute top-3 right-3 w-2.5 h-2.5 bg-rose-500 rounded-full ring-4 ring-[#18181B]" />
           </Link>
        </div>
      </header>

      <main className="px-8 pb-12">
        {/* Welcome Section */}
        <section className="mb-12 relative">
           <div className="flex items-center justify-between gap-8">
              <div>
                 <h1 className="text-4xl font-black text-white mb-2">Hello, {user?.firstName || "Aarav"}! 👋</h1>
                 <p className="text-gray-500 font-bold text-lg">What would you like to learn today?</p>
              </div>
              
              <div className="hidden lg:flex items-center gap-6">
                 <div className="relative">
                    <div className="w-32 h-32 drop-shadow-[0_0_20px_rgba(99,102,241,0.3)]">
                       <img src="https://api.dicebear.com/7.x/bottts/svg?seed=StudyBroody" alt="Broody" className="w-full h-full" />
                    </div>
                    <div className="absolute -bottom-2 -left-2 px-3 py-1 bg-brand-gradient rounded-lg text-white text-[10px] font-black uppercase shadow-lg shadow-indigo-600/20">SB Core</div>
                 </div>
              </div>
           </div>
        </section>

        {/* Tool Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
           {[
             { icon: MessageSquare, title: "Chat with BROODY", desc: "Ask doubts and get instant answers", color: "text-indigo-400", bg: "bg-indigo-500/10", path: "/chat" },
             { icon: Camera, title: "Camera Solver", desc: "Scan questions and get solutions", color: "text-emerald-400", bg: "bg-emerald-500/10", path: "/camera" },
             { icon: LayoutGrid, title: "Quizzes", desc: "Practice and test your knowledge", color: "text-amber-400", bg: "bg-amber-500/10", path: "/updates" },
             { icon: FileText, title: "Notes", desc: "Smart notes and summaries", color: "text-blue-400", bg: "bg-blue-500/10", path: "/updates" },
           ].map((tool) => (
             <div
               key={tool.title}
               onClick={() => navigate(tool.path)}
               className="p-6 bg-[#18181B] rounded-[32px] border border-white/5 flex flex-col items-start gap-4 cursor-pointer hover:bg-white/5 transition-all group relative overflow-hidden"
             >
                <div className={cn("w-14 h-14 rounded-2xl flex items-center justify-center group-hover:scale-110 relative z-10", tool.bg, tool.color)}>
                   <tool.icon className="w-7 h-7" />
                </div>
                <div className="relative z-10">
                   <h3 className="font-black text-white leading-tight mb-1">{tool.title}</h3>
                   <p className="text-[11px] font-bold text-gray-500 transition-colors">{tool.desc}</p>
                </div>
             </div>
           ))}
        </div>

        <div className="grid lg:grid-cols-[1.5fr_1fr] gap-8">
           {/* Left Column: Continue Learning */}
           <div className="space-y-8">
              <section>
                 <div className="flex items-center justify-between mb-6">
                    <h2 className="text-xl font-black text-white tracking-tight">Continue Learning</h2>
                    <button className="text-xs font-black text-indigo-400 uppercase tracking-widest hover:underline">View All</button>
                 </div>
                 <div className="grid md:grid-cols-2 gap-6">
                    {[
                      { title: "Photosynthesis in Plants", emoji: "🌱", subject: "Science • Class 10", progress: 75, color: "bg-emerald-500" },
                      { title: "Linear Equations", emoji: "📐", subject: "Mathematics • Class 9", progress: 40, color: "bg-amber-500" },
                    ].map((item) => (
                      <div 
                        key={item.title} 
                        className="p-5 bg-[#18181B] border border-white/5 rounded-[28px] flex items-center gap-4 hover:bg-white/5 transition-all cursor-pointer group"
                      >
                         <div className="w-14 h-14 rounded-2xl bg-white/5 flex items-center justify-center text-2xl group-hover:scale-110 transition-transform flex-shrink-0">{item.emoji}</div>
                         <div className="flex-1 min-w-0">
                            <h4 className="font-black text-sm text-white truncate mb-1">{item.title}</h4>
                            <p className="text-[11px] font-bold text-gray-500 mb-3">{item.subject}</p>
                            <div className="relative h-2 bg-white/5 rounded-full overflow-hidden">
                               <div 
                                 className={`absolute inset-y-0 ${item.color} rounded-full`}
                                 style={{ width: `${item.progress}%` }}
                               />
                            </div>
                         </div>
                         <span className="text-[11px] font-black text-gray-500">{item.progress}%</span>
                      </div>
                    ))}
                 </div>
              </section>

              <section>
                 <div className="flex items-center justify-between mb-6">
                    <h2 className="text-xl font-black text-white tracking-tight">Today's Goals</h2>
                 </div>
                 <div className="space-y-4">
                    {[
                      { title: "Complete 2 quizzes", icon: "📝", progress: "1/2", checked: false },
                      { title: "Study for 30 minutes", icon: "⏰", progress: "20/30 min", checked: false },
                      { title: "Revise Science notes", icon: "✅", checked: true },
                    ].map((goal, i) => (
                      <div 
                        key={goal.title}
                        className="p-5 bg-[#18181B] border border-white/5 rounded-[24px] flex items-center justify-between cursor-pointer group"
                      >
                         <div className="flex items-center gap-4">
                            <div className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center text-lg">{goal.icon}</div>
                            <span className={`text-[14px] font-black ${goal.checked ? 'text-gray-600 line-through opacity-50' : 'text-gray-300'}`}>{goal.title}</span>
                         </div>
                         <div className="flex items-center gap-4">
                            {goal.progress && <span className="text-[11px] font-black text-gray-500">{goal.progress}</span>}
                            <div className={cn("w-6 h-6 rounded-lg flex items-center justify-center", goal.checked ? "bg-emerald-500 text-white" : "bg-white/5 text-transparent border-2 border-white/10")}>
                               <CheckCircle2 className="w-4 h-4" />
                            </div>
                         </div>
                      </div>
                    ))}
                 </div>
              </section>
           </div>

           {/* Right Column: Progress */}
           <div className="space-y-8">
              <section className="bg-[#18181B] border border-white/5 rounded-[40px] p-8 shadow-2xl flex flex-col items-center">
                 <h2 className="text-xl font-black text-white mb-8 self-start">Your Progress</h2>
                 <div className="relative w-48 h-48 mb-6 flex items-center justify-center">
                    <svg className="w-full h-full -rotate-90">
                       <circle cx="96" cy="96" r="88" stroke="currentColor" strokeWidth="16" fill="transparent" className="text-white/5" />
                       <circle 
                        cx="96" 
                        cy="96" 
                        r="88" 
                        stroke="currentColor" 
                        strokeWidth="16" 
                        fill="transparent" 
                        strokeDasharray="552.92" 
                        strokeDashoffset={552.92 * (1 - 0.72)}
                        className="text-indigo-500" 
                       />
                    </svg>
                    <div className="absolute flex flex-col items-center">
                       <span className="text-4xl font-black text-white">72%</span>
                    </div>
                 </div>
                 <div className="text-center">
                    <h4 className="font-extrabold text-white mb-2 text-[15px]">Great job! Keep it up! 🌟</h4>
                    <button className="px-6 py-2 bg-indigo-500/10 text-indigo-400 font-black rounded-xl text-xs hover:bg-indigo-500/20 transition-all">View Detailed Report</button>
                 </div>
              </section>

              <div className="p-8 bg-brand-gradient rounded-[40px] text-white overflow-hidden relative group shadow-2xl shadow-indigo-600/20">
                 <h3 className="text-2xl font-black mb-2 relative z-10 tracking-tight">Study with BROODY AI</h3>
                 <p className="text-white/80 font-bold mb-6 relative z-10 text-sm">Get personalized help and Ace your exams!</p>
                 <button 
                  onClick={() => navigate('/chat')}
                  className="px-6 py-3 bg-white text-indigo-600 font-extrabold rounded-2xl text-sm relative z-10 hover:shadow-xl"
                 >
                   Go to Chat
                 </button>
              </div>
           </div>
        </div>
      </main>
    </div>
  );
}
