import { Link } from "react-router-dom";
import { ArrowRight } from "lucide-react";
import { cn } from "../lib/utils";
import { motion } from "motion/react";
import { NpcsLogo } from "./NpcsLogo";

interface ProductCardProps {
  product: {
    id: string;
    name: string;
    tagline: string;
    description: string;
    status: string;
    icon: any;
  };
}

export function ProductCard({ product }: ProductCardProps) {
  const isLive = product.status === "live";
  
  if (isLive) {
    return (
      <motion.div 
        whileHover={{ y: -4 }}
        className="h-full bg-hero-gradient border-accent-gradient rounded-[20px] p-7 flex flex-col relative group overflow-hidden"
      >
        <div className="absolute top-7 right-7 bg-[#22c55e1a] text-[#4ADE80] px-3 py-1 rounded-full text-[11px] font-bold tracking-[0.05em] border border-[#22c55e33]">
          LIVE NOW
        </div>

        <div className="relative h-full flex flex-col items-start">
          
          <div className="shrink-0 w-16 h-16 rounded-2xl bg-accent-gradient shadow-[0_0_20px_rgba(99,102,241,0.3)] mb-6 flex items-center justify-center p-[2px]">
            <div className="w-full h-full rounded-2xl flex items-center justify-center flex-col relative overflow-hidden text-white bg-[#09090B]/20">
              <span className="text-[26px] font-black tracking-tighter leading-none shadow-sm">SB</span>
            </div>
          </div>

          <div className="flex-1 flex flex-col">             
             <h2 className="text-[28px] font-bold text-[#E4E4E7] mb-2">{product.name}</h2>
             <p className="text-[#71717A] text-[16px] leading-[1.5] max-w-[320px] mb-6">
               {product.description}
             </p>
             
             <Link 
                to={`/${product.id}`}
                className="mt-auto self-start inline-flex items-center gap-2 px-6 py-3 bg-accent-gradient text-white font-semibold rounded-[10px] text-[14px] transition-transform hover:scale-105"
             >
                Enter {product.name}
                <ArrowRight className="w-4 h-4" />
             </Link>
          </div>
        </div>
      </motion.div>
    );
  }

  // Under construction cards
  return (
    <motion.div 
      whileHover={{ y: -2 }}
      className="bg-[#18181B] rounded-[20px] p-7 border border-[#ffffff14] flex flex-col relative group overflow-hidden h-full"
    >
      <div className="inline-flex items-center gap-1.5 text-[11px] font-semibold text-[#71717A] uppercase mb-3">
        <span className="w-1.5 h-1.5 bg-[#3F3F46] rounded-full" />
        Under Development
      </div>
      
      <div className="flex-1 mb-6 mt-1 flex flex-col">
        <h3 className="text-[22px] font-bold text-[#E4E4E7] mb-2">{product.name}</h3>
        <p className="text-[14px] text-[#71717A] leading-[1.5]">
          {product.description}
        </p>
      </div>

      <Link 
        to={`/product/${product.id}`}
        className="w-full mt-auto inline-flex items-center justify-center gap-2 px-6 py-3 bg-[#ffffff0d] text-[#E4E4E7] font-semibold rounded-[10px] border border-[#ffffff14] text-[14px] transition-all hover:bg-[#ffffff12] relative overflow-hidden group/btn group-hover:bg-[#ffffff12]"
      >
        <NpcsLogo className="w-6 h-6 text-[#E4E4E7]" />
        Open NPCs {product.name}
      </Link>
    </motion.div>
  );
}
