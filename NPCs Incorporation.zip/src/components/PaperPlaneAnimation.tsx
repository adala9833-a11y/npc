import { motion } from "motion/react";
import { Send } from "lucide-react";

export function PaperPlaneAnimation() {
  // A more "swooping" path that feels like a paper plane
  const pathData = "M -100 300 C 100 100 400 500 700 200 C 1000 -100 1300 400 1700 300";
  
  return (
    <div className="absolute inset-0 pointer-events-none overflow-hidden z-[1] opacity-60">
      <svg
        width="100%"
        height="100%"
        viewBox="0 0 1600 600"
        fill="none"
        preserveAspectRatio="none"
        className="absolute top-0 left-0 h-full w-full"
      >
        <motion.path
          d={pathData}
          stroke="url(#planeTrail)"
          strokeWidth="2"
          strokeDasharray="4 8"
          initial={{ pathLength: 0 }}
          animate={{ pathLength: [0, 1, 1, 1], opacity: [1, 1, 1, 0] }}
          transition={{
            duration: 12,
            repeat: Infinity,
            ease: "easeInOut",
          }}
        />
        
        <defs>
          <linearGradient id="planeTrail" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#6366F1" stopOpacity="0" />
            <stop offset="50%" stopColor="#6366F1" stopOpacity="0.4" />
            <stop offset="100%" stopColor="#6366F1" stopOpacity="0.1" />
          </linearGradient>
        </defs>

        <motion.g
          initial={{ offsetDistance: "0%", opacity: 0 }}
          animate={{ 
            offsetDistance: "100%",
            opacity: [0, 1, 1, 0] 
          }}
          transition={{
            duration: 12,
            repeat: Infinity,
            ease: "easeInOut",
          }}
          style={{
            offsetPath: `path("${pathData}")`,
            offsetRotate: "auto 90deg",
          }}
        >
          <motion.path 
            d="M2 21l21-9L2 3v7l15 2-15 2v7z" 
            fill="#EEF2FF"
            stroke="#6366F1"
            strokeWidth="1.5"
            animate={{ 
              rotate: [-10, 10, -10],
            }}
            transition={{
              duration: 1.5,
              repeat: Infinity,
              ease: "easeInOut"
            }}
            style={{
              transformOrigin: "center",
              transform: "scale(1.5) rotate(90deg)"
            }}
          />
        </motion.g>
      </svg>
    </div>
  );
}
