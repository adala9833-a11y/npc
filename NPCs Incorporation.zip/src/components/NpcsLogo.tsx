export function NpcsLogo({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 200 200" fill="none" xmlns="http://www.w3.org/2000/svg" className={className}>
      {/* Outer thick ring */}
      <circle cx="100" cy="100" r="65" stroke="#71717A" strokeWidth="18" opacity="0.8" />
      
      {/* Center dot */}
      <circle cx="100" cy="100" r="10" fill="#71717A" opacity="0.8" />
      
      {/* Dotted crosshairs */}
      <line x1="100" y1="15" x2="100" y2="185" stroke="#71717A" strokeWidth="4" strokeDasharray="4 8" strokeLinecap="round" opacity="0.7" />
      <line x1="15" y1="100" x2="185" y2="100" stroke="#71717A" strokeWidth="4" strokeDasharray="4 8" strokeLinecap="round" opacity="0.7" />
      
      {/* Text NPCS (Upper) */}
      <text x="100" y="92" fill="currentColor" fontSize="56" fontWeight="900" fontFamily="Inter, sans-serif" textAnchor="middle" letterSpacing="-3px">
        NPCS
      </text>
      
      {/* Text INC. (Lower) */}
      <text x="100" y="144" fill="currentColor" fontSize="56" fontWeight="900" fontFamily="Inter, sans-serif" textAnchor="middle" letterSpacing="-3px">
        INC.
      </text>
    </svg>
  );
}
