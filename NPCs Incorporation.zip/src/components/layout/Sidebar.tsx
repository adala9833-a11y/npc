import { Link, useLocation, useNavigate } from "react-router-dom";
import { 
  Home, MessageSquare, Camera, LayoutGrid, FileText, 
  BookOpen, GraduationCap, TrendingUp, Calendar, 
  HelpCircle, Settings, LogOut 
} from "lucide-react";
import { cn } from "../../lib/utils";
import { motion } from "motion/react";
import { NpcsLogo } from "../NpcsLogo";
import { useUser } from "../../contexts/UserContext";

const navItems = [
  { icon: Home, label: "Home", path: "/home" },
  { icon: MessageSquare, label: "Chat with BROODY", path: "/chat" },
  { icon: Camera, label: "Camera Solver", path: "/camera" },
  { icon: LayoutGrid, label: "Quizzes", path: "/updates" },
  { icon: FileText, label: "Notes", path: "/updates" },
  { icon: BookOpen, label: "My Learning", path: "/updates" },
  { icon: GraduationCap, label: "Assignments", path: "/updates" },
  { icon: TrendingUp, label: "Progress", path: "/updates" },
  { icon: Calendar, label: "Calendar", path: "/updates" },
];

export function Sidebar() {
  const location = useLocation();
  const navigate = useNavigate();
  const { user, logout } = useUser();

  const handleLogout = () => {
    logout();
    navigate("/");
  };

  return (
    <div className="w-[260px] h-screen bg-[#18181B] border-r border-white/5 flex flex-col shrink-0 p-6 z-40">
      {/* Logo Area */}
      <div className="flex flex-col items-center gap-2 mb-10 cursor-pointer" onClick={() => navigate('/')}>
        <div className="w-14 h-14 rounded-2xl bg-brand-gradient flex items-center justify-center text-white font-black text-2xl shadow-xl">
           SB
        </div>
        <div className="text-center">
           <h2 className="font-black text-lg text-white tracking-tight leading-none">STUDYBROODY</h2>
           <p className="text-[10px] font-bold text-gray-500 mt-1 uppercase tracking-widest">Your 24×7 AI Study Buddy</p>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 space-y-1 overflow-y-auto no-scrollbar">
        {navItems.map((item) => {
          const isActive = location.pathname === item.path;
          
          return (
            <Link
              key={item.label}
              to={item.path}
              className={cn(
                "flex items-center gap-4 px-4 py-3.5 rounded-2xl transition-all duration-200 text-sm",
                isActive 
                  ? "bg-indigo-600 text-white font-black shadow-lg shadow-indigo-600/20" 
                  : "text-gray-400 font-bold hover:bg-white/5 hover:text-white"
              )}
            >
              <item.icon className={cn("w-5 h-5 shrink-0", isActive ? "text-white" : "text-gray-500")} />
              <span>{item.label}</span>
            </Link>
          );
        })}
        
        <div className="pt-4 border-t border-white/5 mt-4 space-y-1">
           <Link to="/updates" className="flex items-center gap-4 px-4 py-3.5 rounded-2xl text-sm text-gray-500 font-bold hover:bg-white/5 hover:text-white transition-all">
              <HelpCircle className="w-5 h-5 text-gray-500" />
              <span>Get Help</span>
           </Link>
           <Link to="/about" className="flex items-center gap-4 px-4 py-3.5 rounded-2xl text-sm text-gray-500 font-bold hover:bg-white/5 hover:text-white transition-all">
              <Settings className="w-5 h-5 text-gray-500" />
              <span>Manual</span>
           </Link>
        </div>
      </nav>

      {/* User Profile */}
      <div className="mt-auto pt-6 border-t border-white/5">
        <div className="flex items-center gap-3 p-3 bg-white/5 rounded-2xl mb-4">
          <div className="w-10 h-10 rounded-full overflow-hidden border-2 border-[#27272A] shadow-sm shrink-0">
             <img src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${user?.firstName || 'Aarav'}`} alt="Avatar" />
          </div>
          <div className="flex flex-col min-w-0">
            <span className="text-[13px] font-black text-white truncate leading-none mb-1">{user?.firstName || "Aarav"} {user?.lastName || "Sharma"}</span>
            <span className="text-[10px] font-bold text-gray-400 truncate uppercase tracking-wider">{user?.role || "Student"}</span>
          </div>
        </div>
        
        <button 
          onClick={handleLogout}
          className="w-full flex items-center justify-center gap-2 px-4 py-3.5 bg-rose-500/10 text-rose-500 rounded-2xl text-xs font-black hover:bg-rose-500/20 transition-all group border border-rose-500/20"
        >
          <LogOut className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
          Logout
        </button>
      </div>
    </div>
  );
}
