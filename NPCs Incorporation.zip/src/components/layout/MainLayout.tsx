import { Outlet } from "react-router-dom";
import { Sidebar } from "./Sidebar";

export function MainLayout() {
  return (
    <div className="flex h-screen w-full bg-[#09090B] text-[#FAFAFA]">
      <Sidebar />
      <div className="flex-1 overflow-auto no-scrollbar">
        <div className="h-full w-full flex flex-col">
          <Outlet />
        </div>
      </div>
    </div>
  );
}
