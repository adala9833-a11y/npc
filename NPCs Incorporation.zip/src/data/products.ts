import { BookOpen, Code, Database, Cloud, Blocks, Brain, PenTool, TrendingUp, Notebook } from "lucide-react";

export const products = [
  {
    id: "studybroody",
    name: "STUDYBROODY",
    tagline: "AI Learning Companion",
    description: "Your smart AI companion that helps you learn, practice, track progress and achieve more.",
    status: "live",
    icon: BookOpen,
    features: [
      { name: "AI Tutor", icon: Brain },
      { name: "Smart Quizzes", icon: PenTool },
      { name: "Study Notes", icon: Notebook },
      { name: "Performance Analysis", icon: TrendingUp },
    ]
  },
  {
    id: "product-2",
    name: "PROJECT NEXUS",
    tagline: "Collaboration Redefined",
    description: "Connect teams and automate workflows intelligently.",
    status: "development",
    icon: Blocks,
    color: "amber",
  },
  {
    id: "product-3",
    name: "CODECRAFT",
    tagline: "AI Code Assistant",
    description: "Write, test, and deploy code faster with contextual AI pairing.",
    status: "development",
    icon: Code,
    color: "rose",
  },
  {
    id: "product-4",
    name: "DATAORBIT",
    tagline: "Data. Insights. Impact.",
    description: "Transform raw data into meaningful business insights.",
    status: "development",
    icon: Database,
    color: "emerald",
  },
  {
    id: "product-5",
    name: "CLOUDPILOT",
    tagline: "Cloud Management Simplified",
    description: "Orchestrate your multi-cloud environments seamlessly.",
    status: "development",
    icon: Cloud,
    color: "blue",
  },
];
