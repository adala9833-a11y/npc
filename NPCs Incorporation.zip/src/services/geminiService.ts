import { GoogleGenAI } from "@google/genai";

let aiInstance: any = null;

export function getGemini() {
  if (!aiInstance) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error("GEMINI_API_KEY is not set in the environment.");
    }
    aiInstance = new GoogleGenAI({ apiKey });
  }
  return aiInstance;
}

export async function askBroody(prompt: string, history: { role: string; parts: { text: string }[] }[] = []) {
  const ai = getGemini();
  
  // Using gemini-3-flash-preview for fast responses
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: [...history, { role: "user", parts: [{ text: prompt }] }],
    config: {
      systemInstruction: "You are BROODY, a helpful, friendly, and intelligent AI study assistant from NPCs Incorporation. Your goal is to help students learn better by explaining complex topics simply, solving doubts, and providing encouragement. You should be encouraging, smart, and use emojis occasionally to keep things engaging for students.",
    }
  });

  return response.text || "I'm sorry, I couldn't generate a response.";
}
