/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { MainLayout } from "./components/layout/MainLayout";
import { Home } from "./pages/Home";
import { Chat } from "./pages/Chat";
import { CameraSolver } from "./pages/CameraSolver";
import { UnderConstruction } from "./pages/UnderConstruction";
import { VoiceAssistant } from "./pages/VoiceAssistant";
import { StudyBroodyApp } from "./pages/StudyBroody";
import { Landing } from "./pages/Landing";
import { SignUp } from "./pages/SignUp";
import { Welcome } from "./pages/Welcome";
import { UserProvider } from "./contexts/UserContext";

export default function App() {
  return (
    <UserProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Landing />} />
          <Route path="/signup" element={<SignUp />} />
          <Route path="/welcome" element={<Welcome />} />
          
          <Route element={<MainLayout />}>
            <Route path="/home" element={<Home />} />
            <Route path="/chat" element={<Chat />} />
            <Route path="/camera" element={<CameraSolver />} />
            <Route path="/voice-assistant" element={<VoiceAssistant />} />
            <Route path="/product/:id" element={<UnderConstruction />} />
            <Route path="/updates" element={<UnderConstruction />} />
            <Route path="/about" element={<UnderConstruction />} />
            <Route path="/contact" element={<UnderConstruction />} />
          </Route>
          
          {/* Study Broody gets its own full layout */}
          <Route path="/studybroody" element={<StudyBroodyApp />} />
          
          {/* Catch all redirect to landing */}
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </BrowserRouter>
    </UserProvider>
  );
}
