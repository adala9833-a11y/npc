import { createContext, useContext, useState, ReactNode, useEffect } from "react";

interface UserProfile {
  firstName: string;
  lastName: string;
  email: string;
  mobileNumber: string;
  role: 'Student' | 'Teacher';
}

interface UserContextType {
  user: UserProfile | null;
  setUser: (profile: UserProfile) => void;
  logout: () => void;
}

const UserContext = createContext<UserContextType | undefined>(undefined);

export function UserProvider({ children }: { children: ReactNode }) {
  // Try to load from localStorage on init
  const [user, setUserState] = useState<UserProfile | null>(() => {
    const saved = localStorage.getItem("npcs_user");
    return saved ? JSON.parse(saved) : null;
  });

  const setUser = (profile: UserProfile) => {
    setUserState(profile);
    localStorage.setItem("npcs_user", JSON.stringify(profile));
  };

  const logout = () => {
    setUserState(null);
    localStorage.removeItem("npcs_user");
  };

  return (
    <UserContext.Provider value={{ user, setUser, logout }}>
      {children}
    </UserContext.Provider>
  );
}

export function useUser() {
  const context = useContext(UserContext);
  if (context === undefined) {
    throw new Error("useUser must be used within a UserProvider");
  }
  return context;
}
